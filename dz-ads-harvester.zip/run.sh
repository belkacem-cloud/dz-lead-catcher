#!/usr/bin/env bash
set -e
node index.js
node enrich.js
