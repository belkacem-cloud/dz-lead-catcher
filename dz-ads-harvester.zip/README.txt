Run locally: npm i && npm run run
Server mode: npm run serve (POST /run)
Docker: build with provided Dockerfile.
